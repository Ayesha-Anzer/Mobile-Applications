package maani5.com.mathgame;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
public class MainActivity extends AppCompatActivity {
    EditText answerText;
    TextView questionText,tvscore;
    Button Btn;
    TextView messageText;
    int correctAnswer = -1;
    int score =0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //--------------------
        answerText = (EditText) findViewById(R.id.editText_answer);
        questionText = (TextView) findViewById(R.id.textView_Question);
        Btn = (Button) findViewById(R.id.button_answer);
        messageText = (TextView) findViewById(R.id.textView_message);
        tvscore = (TextView) findViewById(R.id.tvscore);
        askQuestion();
        Btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(getAnswer()==true)
                {
                    score = score+1;
                    tvscore.setText(score+"");
                    answerText.setText("");
                    askQuestion();

                }
                else
                {
                    score=score-1;
                    askQuestion();
                }
            }
        });
        //---------------------
    }//end OnCreate
    //*****************
    void askQuestion() {
        int x = (int) Math.floor(10 * Math.random());
        int y = (int) Math.floor(10 * Math.random());
        correctAnswer = x * y;
        String msgTxt = "How much " + x + " times " + y + " ?";
        questionText.setText(msgTxt);

    }

    //**************
    boolean getAnswer() {

        int answer = Integer.parseInt(answerText.getText().toString());
        if (answer == correctAnswer) {
            messageText.setText("Keep up the good work!");
            return true;
        } else {
            messageText.setText("No. Please try again.");
            return false;

        }
    }
}
