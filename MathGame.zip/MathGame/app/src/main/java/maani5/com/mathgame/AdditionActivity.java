package maani5.com.mathgame;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class AdditionActivity extends AppCompatActivity {

    EditText answerText;
    TextView questionText;
    Button Btn;
    TextView messageText,tvscore;
    int correctAnswer = -1;
    int score =0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_multiplicaiton);

        Btn = (Button) findViewById(R.id.btnresult);
        answerText = (EditText) findViewById(R.id.etresult);
        questionText = (TextView) findViewById(R.id.tvq);
        messageText = (TextView) findViewById(R.id.tvresult);
            tvscore = (TextView) findViewById(R.id.tvscore);

        askQuestion();
        Btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(getAnswer()==true)
                {
                    score = score+1;
                    tvscore.setText(score+"");
                    answerText.setText("");
                    askQuestion();

                }
                else
                {
                    score=score-1;
                    askQuestion();
                }
            }
        });

    }

    //*****************
    void askQuestion() {
        int x = (int) Math.floor(10 * Math.random());
        int y = (int) Math.floor(10 * Math.random());
        correctAnswer = x + y;
        String msgTxt = "How much " + x + " + " + y + " ?";
        questionText.setText(msgTxt);

    }

    //**************
    boolean getAnswer() {

        int answer = Integer.parseInt(answerText.getText().toString());
        if (answer == correctAnswer) {
            messageText.setText("Keep up the good work!");
            return true;
        } else {
            messageText.setText("No. Please try again.");
            return false;

        }
    }

}
