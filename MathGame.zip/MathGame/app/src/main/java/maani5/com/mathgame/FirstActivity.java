package maani5.com.mathgame;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.animation.AnimationUtils;
import android.widget.Button;

public class FirstActivity extends AppCompatActivity {
    Button add,sub,mul,div;
    Context context;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_first);
        add = (Button) findViewById(R.id.btnadd);
        sub = (Button) findViewById(R.id.btnsub);
        div = (Button) findViewById(R.id.btndiv);
        mul = (Button) findViewById(R.id.btnmul);
        context = this;


        add.startAnimation(AnimationUtils.loadAnimation(context, R.anim.slide_in_left));
        sub.startAnimation(AnimationUtils.loadAnimation(context, R.anim.slide_in_right));
        div.startAnimation(AnimationUtils.loadAnimation(context, R.anim.slide_in_left));
        mul.startAnimation(AnimationUtils.loadAnimation(context, R.anim.slide_in_right));

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(FirstActivity.this,AdditionActivity.class));
            }
        });

        mul.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(FirstActivity.this,MainActivity.class));

            }
        });

        sub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(FirstActivity.this,SubtractionActivity.class));
            }
        });

        div.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(FirstActivity.this,DivisionActivity.class));
            }
        });
    }
}
